package SetDemo;

import java.util.HashSet;
import java.util.Set;

public class SetMain {
	public static void main(String[] args) {
		Set<String> st = new HashSet<String>();
		st.add("entry1");
		st.add("entry2");
		st.add("entry3");
		
		EntrySet et= new EntrySet();
		
		et.printset(st);
		System.out.println(st.size());
		
		Set<String> st2 = new HashSet<String>();

		
		EntrySet et1= new EntrySet();
		et1.printset(st2);
		System.out.println(st2.size());
	}
}	
