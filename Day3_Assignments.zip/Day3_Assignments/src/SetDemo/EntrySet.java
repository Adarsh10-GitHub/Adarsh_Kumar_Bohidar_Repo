package SetDemo;

import java.util.Iterator;
import java.util.Set;

public class EntrySet {
	
	public void printset(Set<String> set) {
		if(set.isEmpty()) {
			System.out.println("Set is empty ");
		}
		else 
		{
			Iterator<String> it=set.iterator();
			System.out.println("The set values are : ");
			while(it.hasNext()) {
				System.out.println(it.next());
			}
		}
	}
}
