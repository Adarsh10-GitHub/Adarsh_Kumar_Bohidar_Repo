package com.seed.bank;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AddCustomers {
	
	public void DisplayCustomers(List<String> arrayList) 
	{
		Iterator<String> iterator = arrayList.iterator();
		System.out.println("Customers are: ");
		while(iterator.hasNext()) 
		{
			System.out.println(iterator.next());
		}
	}
	
}
