package com.seed.login;

import java.util.LinkedHashMap;
import java.util.Map;

public class LoginMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, String> mp = new LinkedHashMap<Integer, String>();
		mp.put(1002, "adrash");
		mp.put(1290, "Rohan");
		mp.put(1200, "Rahul");
		mp.put(1003, "Ankit");
		
		System.out.println("Before adding 1003" + mp);
		LoginDetails login = new LoginDetails();
		login.samekey(mp);
		System.out.println(mp);
		
		login.printdetails(mp);
	}

}
