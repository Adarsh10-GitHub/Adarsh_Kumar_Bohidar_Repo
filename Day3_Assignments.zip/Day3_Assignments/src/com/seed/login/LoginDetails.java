package com.seed.login;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class LoginDetails {
	public void samekey(Map<Integer, String> map) 
	{
		if(map.containsKey(1003)) {
			System.out.println("Key already exist");
		}
		
			map.put(1003, "John");
	
	}
	
	
	public void printdetails(Map<Integer, String> map) 
	{
		Set<Integer> st = map.keySet();
		Iterator<Integer> it = st.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
