package assignments1;

public class ByteData {
	public static void main(String[] args) {
		
		int val = 200;
		System.out.println((byte)val);
		byte max =127;
		byte min = -128;
		byte sum = (byte) (max + min);
		
		System.out.println("Sum :"+sum);
		
	}
}
