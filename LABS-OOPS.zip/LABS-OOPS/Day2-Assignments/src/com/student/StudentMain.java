package com.student;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student('D',"Bony","Thomas");
		s1.displayDetails();
		Student s2= new Student('H',"Dinil","Bose");
		s2.displayDetails();
	}

}
