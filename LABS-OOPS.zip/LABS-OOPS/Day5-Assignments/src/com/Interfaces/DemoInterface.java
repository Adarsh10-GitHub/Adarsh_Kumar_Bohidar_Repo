package com.Interfaces;

public class DemoInterface {
	
	public static void main(String[] args) {
		Example obj= new Example();
		obj.methodOne();
		obj.methodTwo();
	}

}
