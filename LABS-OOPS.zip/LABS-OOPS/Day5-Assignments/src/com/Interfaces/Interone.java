package com.Interfaces;

public interface Interone {
//var1 needs to be initialized
	int varOne=1;
	int vartwo=100;
	void methodOne();
	void methodTwo();
	
	
	
	
}

