package com.Interfaces;

public class Example implements Interone {
    
	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		//vartwo = vartwo+10;
		System.out.println("Value of varTwo:"+ vartwo);
		System.out.println("Good Afternoon");
		
		
	}

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("Good Afternoon");
	}

}
