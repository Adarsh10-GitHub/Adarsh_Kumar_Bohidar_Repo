package com.Accessspecifiers;

public class Registration {

	public static void main(String[] args) {
		DayScholor dayscholor = new DayScholor();
		dayscholor.setStudentId(1001);
		dayscholor.setStudentType('D');
		dayscholor.setStudentname("subbu");
		dayscholor.getDetails();
		
	}
}
