package FinalStudent;

public class NewMain {
	public static void main(String[] args) {
		 DayScholar s1 = new DayScholar();
		 s1.setSid(1);
		 s1.setSname("Adarsh");
		 s1.setStype('H');
		 s1.calculatefees();
		 s1.setAddress("chennai");
		 s1.DisplayDetails();
		 
	}
}
