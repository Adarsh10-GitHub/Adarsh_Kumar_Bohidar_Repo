package Inheritance;

public class HostelMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hostelite h1 = new Hostelite(7, "Adarsh", "Bohidar", 'H', "A1", 92);
		System.out.println(h1.getHostelname() +" "+h1.getRoomnumber()+" "+h1.getStudentid() +" "+h1.getStudentname()+" "+h1.getStype());

	}

}
