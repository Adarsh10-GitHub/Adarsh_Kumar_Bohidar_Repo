package assignment8;





public class InsufficientFundException extends Exception {
	public InsufficientFundException(String msg){
		super(msg);
}
}
