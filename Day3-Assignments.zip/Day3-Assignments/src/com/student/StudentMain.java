package com.student;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student('H',"Adarsh");
		Student s2=new Student('D',"Harsh");
		
		System.out.println(Student.getstudentCount());
	}

}
