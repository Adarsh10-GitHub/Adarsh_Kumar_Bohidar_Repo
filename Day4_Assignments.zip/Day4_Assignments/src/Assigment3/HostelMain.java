package Assigment3;

public class HostelMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hostelite h1 = new Hostelite(7, "Adarsh", "Bohidar", 'H', 1000,"A1", 99);
		h1.displayStudentDetails();
		
		DayScholar ds1= new DayScholar(8, "Rahul", "Kumar", 'D',80000, "Chennai");
		ds1.displayStudentDetails();
	}

}
